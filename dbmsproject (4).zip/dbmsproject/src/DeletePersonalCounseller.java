import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeletePersonalCounseller extends Frame 
{
	Button deletePersonalCounsellerButton;
	List PersonalCounsellerIDList;
	TextField cidText, cnameText, experienceText, ageText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeletePersonalCounseller() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hyndavi","hyndhu3612");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadPersonalCounseller() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM personalcounseller");
		  while (rs.next()) 
		  {
			PersonalCounsellerIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    PersonalCounsellerIDList = new List(10);
		loadPersonalCounseller();
		add(PersonalCounsellerIDList);
		
		//When a list item is selected populate the text fields
		PersonalCounsellerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM personalcounseller");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(PersonalCounsellerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CID"));
						cnameText.setText(rs.getString("CNAME"));
						experienceText.setText(rs.getString("EXPERIENCE"));
						ageText.setText(rs.getString("AGE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deletePersonalCounsellerButton = new Button("Delete PersonalCounseller");
		deletePersonalCounsellerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM personalcounseller WHERE CID = "
							+ PersonalCounsellerIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidText.setText(null);
					cnameText.setText(null);
					experienceText.setText(null);
					ageText.setText(null);
					PersonalCounsellerIDList.removeAll();
					loadPersonalCounseller();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cnameText = new TextField(15);
		experienceText = new TextField(15);
		ageText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("PersonalCounseller ID:"));
		first.add(cidText);
		first.add(new Label("Name:"));
		first.add(cnameText);
		first.add(new Label("Experience:"));
		first.add(experienceText);
		first.add(new Label("Age:"));
		first.add(ageText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deletePersonalCounsellerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove PersonalCounseller");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeletePersonalCounseller delpc = new DeletePersonalCounseller();

		delpc.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		delpc.buildGUI();
	}
}

