import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateDepartment extends Frame 
{
	Button updateDepartmentButton;
	List DepartmentIDList;
	TextField didText, dnameText,hodText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateDepartment() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hyndavi","hyndhu3612");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadDepartment() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT DID FROM Department");
		  while (rs.next()) 
		  {
			DepartmentIDList.add(rs.getString("DID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    DepartmentIDList = new List(10);
		loadDepartment();
		add(DepartmentIDList);
		
		//When a list item is selected populate the text fields
		DepartmentIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Department where DID ="+DepartmentIDList.getSelectedItem());
					rs.next();
					didText.setText(rs.getString("DID"));
					dnameText.setText(rs.getString("DNAME"));
					//ratingText.setText(rs.getString("RATING"));
					hodText.setText(rs.getString("HOD"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateDepartmentButton = new Button("Update Department");
		updateDepartmentButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Department "
					+ "SET dname='" + dnameText.getText() + "', "
					+ "hod ="+ "'"+hodText.getText() + "' WHERE did = "
					+ DepartmentIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					DepartmentIDList.removeAll();
					loadDepartment();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		didText = new TextField(15);
		didText.setEditable(false);
		dnameText = new TextField(15);
		//ratingText = new TextField(15);
		hodText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Department ID:"));
		first.add(didText);
		first.add(new Label("Name:"));
		first.add(dnameText);
		//first.add(new Label("Rating:"));
		//first.add(ratingText);
		first.add(new Label("HOD:"));
		first.add(hodText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateDepartmentButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Department");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateDepartment upd = new UpdateDepartment();

		upd.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upd.buildGUI();
	}
}

