import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteProctor extends Frame 
{
	Button deleteProctorButton;
	List proctorIDList;
	TextField pidText, pnameText,experienceText, ageText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteProctor() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hyndavi","hyndhu3612");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadProctor() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM proctor");
		  while (rs.next()) 
		  {
			proctorIDList.add(rs.getString("PID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    proctorIDList = new List(10);
		loadProctor();
		add(proctorIDList);
		
		//When a list item is selected populate the text fields
		proctorIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM proctor");
					while (rs.next()) 
					{
						if (rs.getString("PID").equals(proctorIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						pidText.setText(rs.getString("PID"));
						pnameText.setText(rs.getString("PNAME"));
						experienceText.setText(rs.getString("EXPERIENCE"));
						ageText.setText(rs.getString("AGE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteProctorButton = new Button("Delete proctor");
		deleteProctorButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM proctor WHERE PID = "
							+ proctorIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					pidText.setText(null);
					pnameText.setText(null);
					experienceText.setText(null);
					ageText.setText(null);
					proctorIDList.removeAll();
					loadProctor();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		pidText = new TextField(15);
		pnameText = new TextField(15);
		experienceText = new TextField(15);
		ageText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Proctor ID:"));
		first.add(pidText);
		first.add(new Label("Name:"));
		first.add(pnameText);
		first.add(new Label("Experience:"));
		first.add(experienceText);
		first.add(new Label("Age:"));
		first.add(ageText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteProctorButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Proctor");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteProctor proc = new DeleteProctor();

		proc.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		proc.buildGUI();
	}
}

