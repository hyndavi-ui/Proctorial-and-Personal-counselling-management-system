import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateStudent extends Frame 
{
	Button updateStudentButton;
	List studentIDList;
	TextField sidText, snameText, dobText, gradeText,genderText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateStudent() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hyndavi","hyndhu3612");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudents() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SID FROM students");
		  while (rs.next()) 
		  {
			studentIDList.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    studentIDList = new List(10);
		loadStudents();
		add(studentIDList);
		
		//When a list item is selected populate the text fields
		studentIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM students where SID ="+studentIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("SID"));
					snameText.setText(rs.getString("SNAME"));
					dobText.setText(rs.getString("DOB"));
					gradeText.setText(rs.getString("GRADE"));
					genderText.setText(rs.getString("GENDER"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateStudentButton = new Button("Update Student");
		updateStudentButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE students "
					+ "SET sname='" + snameText.getText() + "', "
					+ "dob='" + dobText.getText() + "', "
					+ "grade ="+ gradeText.getText() +", "
                                        + "gender ='"+ genderText.getText() + "' WHERE sid = "
					+ studentIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					studentIDList.removeAll();
					loadStudents();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		snameText = new TextField(15);
		dobText = new TextField(15);
		gradeText = new TextField(15);
		genderText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Sailor ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Dob:"));
		first.add(dobText);
		first.add(new Label("Grade:"));
		first.add(gradeText);
		first.add(new Label("Gender:"));
                first.add(genderText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateStudentButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Student");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateStudent upst = new UpdateStudent();

		upst.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upst.buildGUI();
	}
}

