import java.awt.*; 
import java.awt.event.*; 

class proctorialSystem extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  InsertStudent stu;
	  UpdateStudent upst;
	  DeleteStudent dels;
	  InsertProctor proc;
          UpdateProctor uppro;
          DeleteProctor delpro;
	  InsertPersonalCounseller perc;
          UpdatePersonalCounseller uppc;
          DeletePersonalCounseller delpc;
	  InsertDepartment dep;
          UpdateDepartment upd;
          DeleteDepartment deld;
	  //MakeReservation mks;
	  personalCounseller_student pcs;
	  proctor_student ps;
	  proctor_personalCounseller ppc;
	  department_student ds;

	  
	  proctorialSystem() 
	  { 
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setBounds(100,300,300,150); 			
			ll.setText("Welcome to proctorial system");
			add(ll);
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu student = new Menu("Student"); 
			MenuItem item1, item2, item3; 
			student.add(item1 = new MenuItem("Submit Student")); 
			student.add(item2 = new MenuItem("Modify Student")); 
			student.add(item3 = new MenuItem("Delete Student")); 
			mbar.add(student);  
		 
			Menu proctor = new Menu("proctor"); 
			MenuItem item4, item5, item6; 
			 proctor.add(item4 = new MenuItem("Submit proctor")); 
			 proctor.add(item5 = new MenuItem("Modify proctor")); 
			 proctor.add(item6 = new MenuItem("Delete  proctor"));  
			mbar.add(proctor);
		       Menu personalCounseller = new Menu("personalCounseller");
                        MenuItem item7, item8, item9;
                         personalCounseller.add(item7 = new MenuItem("Submit personalCounseller"));
                         personalCounseller.add(item8 = new MenuItem("Modify personalCounseller"));
                         personalCounseller.add(item9= new MenuItem("Delete  personalCounseller"));
                        mbar.add(personalCounseller);
			 Menu department = new Menu("department");
                        MenuItem item10, item11, item12;
                        department.add(item10 = new MenuItem("Submit department"));
                        department.add(item11= new MenuItem("Modify department"));
                        department.add(item12= new MenuItem("Delete department"));
                        mbar.add(department);
		
			
			Menu proctor_student = new Menu("proctor_student"); 
			MenuItem item13, item14, item15; 
			proctor_student.add(item13 = new MenuItem("Submit proctor_student")); 
			//proctor_student.add(item14= new MenuItem("Modify student_proctor")); 
			//proctor_student.add(item15= new MenuItem("Delete student_proctor")); 
			mbar.add(proctor_student);
		       Menu  department_student = new Menu(" department_student");
                        MenuItem item16, item17, item18;
                         department_student.add(item16 = new MenuItem("Submit department_student"));
                         //department_student.add(item17= new MenuItem("Modify  department_student"));
                         //department_student.add(item18= new MenuItem("Delete  department_student"));
                        mbar.add( department_student);
		Menu  personalCounseller_student= new Menu(" personalCounseller_student");
                        MenuItem item19, item20, item21;
                         personalCounseller_student.add(item19 = new MenuItem("Submit personalCounseller_student"));
                         //personalCounseller_student.add(item20= new MenuItem("Modify  personalCounseller_student"));
                         //personalCounseller_student.add(item21= new MenuItem("Delete  personalCounseller_student"));
                        mbar.add( personalCounseller_student);
		Menu proctor_personalCounseller = new Menu("proctor_personalCounseller");
                        MenuItem item22, item23, item24;
                        proctor_personalCounseller.add(item22 = new MenuItem("Submit proctor_personalCounseller"));
                        //proctor_personalCounseller.add(item23= new MenuItem("Modify proctor_personalCounseller"));
                        //proctor_personalCounseller.add(item24 = new MenuItem("Delete proctor_personalCounseller"));
                        mbar.add(proctor_personalCounseller);	
			
			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this);
		       item10.addActionListener(this);	
			item11.addActionListener(this);
                        item12.addActionListener(this);
                        item13.addActionListener(this);
                        //item14.addActionListener(this);
                        //item15.addActionListener(this);
                        item16.addActionListener(this);
                        //item17.addActionListener(this);
                        //item18.addActionListener(this);
                        item19.addActionListener(this);
			 //tem20.addActionListener(this);
                        //item21.addActionListener(this);
                        item22.addActionListener(this);
                        //item23.addActionListener(this);
                        //item24.addActionListener(this);			
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Proctorial system"); 
			Color clr = new Color(200, 100, 150);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setLayout(null);
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 

		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Submit Student"))
		  {
			stu = new InsertStudent();

			stu.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				stu.dispose();
			}
			});		
			stu.buildGUI();	
          }			
		 
		 else if(arg.equals("Modify Student")) 
		 {
			upst = new UpdateStudent();
			upst.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upst.dispose();
			}
			});		
			upst.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Student")) 
		 {
			dels = new DeleteStudent();

			dels.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dels.dispose();
			}
			});		
			dels.buildGUI();		 
		 }
		 else if(arg.equals("Submit proctor"))
                  {
                        proc = new InsertProctor();

                        proc.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                proc.dispose();
                        }
                        });
                        proc.buildGUI();
          }

                 else if(arg.equals("Modify proctor"))
                 {
                        uppro = new UpdateProctor();
                        uppro.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                    {
                                uppro.dispose();
                        }
                        });
                        uppro.buildGUI();
                 }
		  else if(arg.equals("Delete proctor"))
                 {
                        delpro = new DeleteProctor();

                        delpro.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                delpro.dispose();
                        }
                        });
                        delpro.buildGUI();
                 }
		 else if(arg.equals("Submit personalCounseller"))
                  {
                        perc = new InsertPersonalCounseller();

                        perc.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                perc.dispose();
                        }
                        });
                        perc.buildGUI();
          }

                 else if(arg.equals("Modify personalCounseller"))
                 {
                        uppc = new UpdatePersonalCounseller();
                        uppc.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                    {
                                uppc.dispose();
                        }
                        });
                        uppc.buildGUI();
                 }
		  else if(arg.equals("Delete personalCounseller"))
                 {
                        delpc = new DeletePersonalCounseller();

                        delpc.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                delpc.dispose();
                        }
                        });
                        delpc.buildGUI();
                 }
		else if(arg.equals("Submit department"))
                  {
                        dep = new InsertDepartment();

                        dep.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                dep.dispose();
                        }
                        });
                        dep.buildGUI();
          }

                 else if(arg.equals("Modify department"))
                 {
                        upd = new UpdateDepartment();
                        upd.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                    {
                                upd.dispose();
                        }
                        });
                        upd.buildGUI();
                 }
		else if(arg.equals("Delete department"))
                 {
                        deld = new DeleteDepartment();

                        deld.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                deld.dispose();
                        }
                        });
                        deld.buildGUI();
                 } 
		 else if(arg.equals("Submit proctor_student")) 
		 {
			ps = new proctor_student();
			setVisible(false); 
			ps.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				ps.dispose();
				setVisible(true);
			}
			});		
			ps.buildGUI();		 
		 }
		 else if(arg.equals("Submit department_student"))
                 {
                        ds = new department_student();
                        setVisible(false);
                        ds.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                ds.dispose();
                                setVisible(true);
                        }
                        });
                        ds.buildGUI();
                 }
		 else if(arg.equals("Submit personalCounseller_student"))
                 {
                        pcs = new personalCounseller_student();
                        setVisible(false);
                        pcs.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                pcs.dispose();
                                setVisible(true);
                        }
                        });
                        pcs.buildGUI();
                 }
		 else if(arg.equals("Submit proctor_personalCounseller"))
                 {
                        ppc = new proctor_personalCounseller();
                        setVisible(false);
                        ppc.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                                ppc.dispose();
                                setVisible(true);
                        }
                        });
                        ppc.buildGUI();
                 }		 
	  }
	  public static void main(String ... args)
	  {
			new proctorialSystem();	  
	  }
} 
 

 

