import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdatePersonalCounseller extends Frame 
{
	Button updatePersonalCounsellerButton;
	List PersonalCounsellerIDList;
	TextField cidText, cnameText, experienceText, ageText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdatePersonalCounseller() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hyndavi","hyndhu3612");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadPersonalCounseller() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT CID FROM personalcounseller");
		  while (rs.next()) 
		  {
			PersonalCounsellerIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    PersonalCounsellerIDList = new List(10);
		loadPersonalCounseller();
		add(PersonalCounsellerIDList);
		
		//When a list item is selected populate the text fields
		PersonalCounsellerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM personalcounseller where CID ="+PersonalCounsellerIDList.getSelectedItem());
					rs.next();
					cidText.setText(rs.getString("CID"));
					cnameText.setText(rs.getString("CNAME"));
					experienceText.setText(rs.getString("EXPERIENCE"));
					ageText.setText(rs.getString("AGE"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updatePersonalCounsellerButton = new Button("Update PersonalCounseller");
		updatePersonalCounsellerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE personalcounseller "
					+ "SET cname='" + cnameText.getText() + "', "
					+ "experience=" + experienceText.getText() + ", "
					+ "age ="+ ageText.getText() + " WHERE cid = "
					+ PersonalCounsellerIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					PersonalCounsellerIDList.removeAll();
					loadPersonalCounseller();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		cnameText = new TextField(15);
	experienceText = new TextField(15);
		ageText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("PersonalCounseller ID:"));
		first.add(cidText);
		first.add(new Label("Name:"));
		first.add(cnameText);
		first.add(new Label("Experience:"));
		first.add(experienceText);
		first.add(new Label("Age:"));
		first.add(ageText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updatePersonalCounsellerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update PersonalCounseller");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdatePersonalCounseller uppc = new UpdatePersonalCounseller();

		uppc.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		uppc.buildGUI();
	}
}

